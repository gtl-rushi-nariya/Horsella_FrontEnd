const getRaceByUser = require('../../../utilities/db/racing/getRaceByUser');
const checkIfUserExists = require('../../../utilities/db/user/checkIfUserExists');

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const getRacesByUser = async (req, resp) => {
  try {
    const { userId } = req;
    if (await checkIfUserExists(userId)) {
      getRaceByUser(userId)
        .then((results) => {
          resp.status(200).json(results);
        })
        .catch((err) => {
          returnError(err, resp);
        });
    }
  } catch (err) {
    returnError(err, resp);
  }
};

module.exports = getRacesByUser;
