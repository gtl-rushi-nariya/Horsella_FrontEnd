const validator = require('validator');
const postParticipation = require('../../../utilities/db/racing/postParticipation');
const checkIfUserExists = require('../../../utilities/db/user/checkIfUserExists');
const checkIfHorseExists = require('../../../utilities/db/horse/checkIfHorseExists');
const checkIfRaceExists = require('../../../utilities/db/racing/checkIfRaceExists');

const details = {
  userId: null,
  raceId: null,
  horseId: null,
  riderName: null,
};

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const registerParticipant = async (req, resp) => {
  try {
    if (req.body !== undefined || req.body !== null) {
      details.userId = req.userId;
      details.raceId = parseInt(req.params.id, 10);
      details.horseId = parseInt(req.body.horseId, 10);
      if (validator.isEmpty(req.body.riderName) || req.body.riderName.length < 3) {
        throw new Error('Invalid Rider Name');
      }
      details.riderName = req.body.riderName;

      const promiseArray = [];
      promiseArray.push(checkIfUserExists(details.userId));
      promiseArray.push(checkIfRaceExists(details.raceId));
      promiseArray.push(checkIfHorseExists(details.horseId));

      Promise.all(promiseArray)
        .then((values) => {
          if (values[0] && values[1] && values[2]) {
            postParticipation(details)
              .then((result) => {
                resp.status(201).json(result);
              })
              .catch((err) => {
                returnError(err, resp);
              });
          } else {
            // eslint-disable-next-line no-nested-ternary
            const error = !values[0] ? 'Invalid user id' : !values[1] ? 'Invalid race id' : 'Invalid horse id';
            returnError({ message: error }, resp);
          }
        });
    }
  } catch (err) {
    returnError(err, resp);
  }
};

module.exports = registerParticipant;
