const getParticipationByRace = require('../../../utilities/db/racing/getParticipationByRace');
const checkIfRaceExists = require('../../../utilities/db/racing/checkIfRaceExists');

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const getParticipants = async (req, resp) => {
  try {
    const raceId = parseInt(req.params.id, 10);
    if (await checkIfRaceExists(raceId)) {
      getParticipationByRace(raceId)
        .then((results) => {
          resp.status(200).json(results);
        })
        .catch((err) => {
          returnError(err, resp);
        });
    }
  } catch (err) {
    returnError(err, resp);
  }
};

module.exports = getParticipants;
