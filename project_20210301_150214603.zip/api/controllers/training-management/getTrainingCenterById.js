const validator = require("validator");
const getTrainingCenterByIdDb = require("../../../utilities/db/training/getTrainingCenterById");

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const getTrainingCenterById = async (req, resp) => {
  var entityData = {
    Id: req.params.id,
  };

  function validateFields(req, res) {
    return new Promise(function (resolve, reject) {
      var isUserIdEmpty = validator.isEmpty(entityData.Id);
      if (isUserIdEmpty) {
        return reject("Training Center id is null");
      }

      return resolve("id exists");
    });
  }

  try {
    validateFields(req, resp)
      .then(function (response) {
        return getTrainingCenterByIdDb(entityData.Id);
      })
      .then((values) => {
        if (values != null) {
          resp.status(200).json({
            status: 200,
            data: values,
            error: null,
          });
        } else {
          resp.status(200).json({
            status: 200,
            data: `training center with id : ${entityData.Id} doesn't exist !!!`,
            error: null,
          });
        }
      })
      .catch(function (err) {
        console.error(err.message);
        returnError(err, resp);
      });
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = getTrainingCenterById;
