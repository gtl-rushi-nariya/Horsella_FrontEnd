const validator = require('validator');
const deleteTrainingCenterDb = require('../../../utilities/db/training/deleteTrainingCenter');
const checkIfTrainingCenterExists = require('../../../utilities/db/training/checkIfTrainingCenterExists');

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const deleteTrainingCenter = async (req, resp) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (await checkIfTrainingCenterExists(id)) {
      deleteTrainingCenterDb(id)
        .then(() => {
          resp.status(204).send();
        })
        .catch((err) => {
          returnError(err, resp);
        });
    } else {
      returnError({ message: 'Invalid training center id' }, resp);
    }
  } catch (err) {
    returnError(err, resp);
  }
};

module.exports = deleteTrainingCenter;
