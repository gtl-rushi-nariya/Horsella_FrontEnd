const validator = require('validator');
const putTrainingCenter = require('../../../utilities/db/training/updateTrainingCenter');
const checkIfTrainingCenterExists = require('../../../utilities/db/training/checkIfTrainingCenterExists');

let trainingCenter = {
  id: null,
  centerName: null,
  ownerName: null,
  description: null,
  workingHours: null,
  experience: null,
  contact: null,
  email: null,
  address: null,
  website: null,
  imagePath: null,
};

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const isNotString = (param) => typeof param !== 'string';

const validateCredentials = ({
  centerName,
  ownerName,
  description,
  workingHours = null,
  experience = null,
  contact,
  email,
  address,
  website = null,
  imagePath = null,
}) => {
  if (isNotString(centerName) || centerName.length < 3) {
    throw new Error('Invalid Center Name');
  }
  if (isNotString(ownerName) || ownerName.length < 3) {
    throw new Error('Invalid Owner Name');
  }
  if (isNotString(description) || description.length < 10) {
    throw new Error('Invalid Description');
  }
  if (isNotString(email) || !validator.isEmail(email)) {
    throw new Error('Invalid Email');
  }
  if (
    experience !== null
    && (isNotString(experience)
      || !validator.isInt(experience, { min: 1, max: 100 }))
  ) {
    throw new Error('Invalid Experience');
  }
  if (isNotString(address) || address.length < 10) {
    throw new Error('Invalid Address');
  }
  if (website !== null && (isNotString(website) || website.length < 3)) {
    throw new Error('Invalid Website URL');
  }
  if (
    workingHours !== null
    && (isNotString(workingHours) || workingHours.length < 3)
  ) {
    throw new Error('Invalid Working Hours');
  }

  if (isNotString(contact) || !validator.isMobilePhone(contact, 'en-IN')) {
    throw new Error('Invalid Contact');
  }
  if (imagePath !== null && (isNotString(website) || imagePath.length < 3)) {
    throw new Error('Invalid Image Path');
  }

  trainingCenter = {
    id: trainingCenter.id,
    centerName,
    ownerName,
    description,
    workingHours,
    experience: parseInt(experience, 10),
    contact,
    email,
    address,
    website,
    imagePath,
  };
};

const updateTrainingCenter = async (req, resp) => {
  if (req.file) {
    const imageName = req.file.filename;
    req.body.imagePath = imageName;
  } else {
    req.body.imagePath = null;
  }

  try {
    if (req.body === undefined || req.body === null) {
      throw new Error('No data found');
    } else {
      trainingCenter.id = parseInt(req.params.id, 10);
      if (await checkIfTrainingCenterExists(trainingCenter.id)) {
        validateCredentials(req.body);
        putTrainingCenter(trainingCenter)
          .then((values) => {
            resp.status(200).json({
              status: 200,
              data: {
                centerName: values.centerName,
                ownerName: values.ownerName,
                email: values.email,
                address: values.address,
                imagePath: values.imagePath,
              },
              error: null,
            });
          })
          .catch((err) => {
            console.error(err.message);
            returnError(err, resp);
          });
      } else {
        returnError({ message: 'Invalid Training Center Id' }, resp);
      }
    }
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = updateTrainingCenter;
