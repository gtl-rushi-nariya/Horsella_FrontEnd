const getAllSellingHorsesDb = require('../../../../utilities/db/horse/selling/getAllSellingHorse');

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const getAllSellingHorses = (req, resp) => {
  try {
    getAllSellingHorsesDb()
      .then((result) => {
        resp.status(200).json(result);
      })
      .catch((err) => {
        returnError(err, resp);
      });
  } catch (err) {
    returnError(err, resp);
  }
};

module.exports = getAllSellingHorses;
