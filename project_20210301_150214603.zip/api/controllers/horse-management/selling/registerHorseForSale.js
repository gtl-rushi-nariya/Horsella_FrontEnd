const { default: validator } = require('validator');
const registerHorseForSaleDb = require('../../../../utilities/db/horse/selling/registerHorseForSale');

const details = {
  userId: null,
  horseId: null,
  price: null,
};

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const registerHorseForSale = (req, resp) => {
  try {
    details.userId = req.userId;
    details.horseId = parseInt(req.params.horseId, 10);
    details.price = parseFloat(req.body.price);
    registerHorseForSaleDb(details)
      .then((result) => {
        resp.status(200).json({
          status: 200,
          data: result,
          error: null,
        });
      })
      .catch((err) => {
        returnError(err, resp);
      });
  } catch (err) {
    returnError(err);
  }
};

module.exports = registerHorseForSale;
