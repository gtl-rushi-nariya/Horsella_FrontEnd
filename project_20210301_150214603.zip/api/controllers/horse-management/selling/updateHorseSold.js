const updateHorseSoldDb = require('../../../../utilities/db/horse/selling/updateHorseSold');

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const updateHorseSold = (req, resp) => {
  try {
    const { userId } = req;
    const saleId = parseInt(req.params.saleId, 10);
    updateHorseSoldDb({ saleId, userId })
      .then((result) => {
        resp.status(200).json({
          status: 200,
          data: result,
          error: null,
        });
      })
      .catch((err) => {
        returnError(err, resp);
      });
  } catch (err) {
    returnError(err, resp);
  }
};

module.exports = updateHorseSold;
