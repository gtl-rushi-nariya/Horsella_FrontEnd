const getAllSellingHorsesByUserDb = require('../../../../utilities/db/horse/selling/getAllSellingHorseByUser');
const checkIfUserExists = require('../../../../utilities/db/user/checkIfUserExists');

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};


const getAllSellingHorseByUser = async (req, resp) => {
  try {
    if (await checkIfUserExists(req.userId)) {
      getAllSellingHorsesByUserDb(req.userId)
        .then((result) => {
          resp.status(200).json({
            status: 200,
            data: result,
            error: null,
          });
        })
        .catch((err) => {
          returnError(err, resp);
        });
    }
    returnError({ message: 'Invalid User id' }, resp);
  } catch (err) {
    returnError(err, resp);
  }
};

module.exports = getAllSellingHorseByUser;
