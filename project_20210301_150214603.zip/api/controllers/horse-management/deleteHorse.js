const validator = require('validator');
const deleteHorseByIdDb = require('../../../utilities/db/horse/deleteHorse');

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const deleteHorse = async (req, resp) => {
  try {
    const id = parseInt(req.params.id, 10);
    deleteHorseByIdDb(id)
      .then((result) => {
        if (result) {
          resp.status(204).send();
        } else {
          resp.status(500).json({
            status: 500,
            data: ` id : ${id} doesn't exist !!!`,
            error: null,
          });
        }
      })
      .catch((err) => {
        console.error(err.message);
        returnError(err, resp);
      });
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = deleteHorse;
