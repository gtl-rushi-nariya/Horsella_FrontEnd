const validator = require('validator');
const getHorsesByUserIdDb = require('../../../utilities/db/horse/getHorseByUserId');
const checkIfUserExists = require('../../../utilities/db/user/checkIfUserExists');

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const getAllHorsesByUserId = async (req, resp) => {
  try {
    if (await checkIfUserExists(req.userId)) {
      getHorsesByUserIdDb(req.userId)
        .then((values) => {
          resp.status(200).json({
            status: 200,
            data: values,
            error: null,
          });
        })
        .catch((err) => {
          returnError(err, resp);
        });
    }
    returnError({ message: 'Invalid User Id' }, resp);
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = getAllHorsesByUserId;
