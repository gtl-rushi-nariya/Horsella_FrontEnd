const validator = require('validator');
const putHorse = require('../../../utilities/db/horse/updateHorse');

let horse = {
  id: null,
  horseName: null,
  ownerId: null,
  showName: null,
  genderId: null,
  breedId: null,
  colorId: null,
  disciplineId: null,
  microchipNumber: null,
  horseWeight: null,
  horseHeight: null,
  birthDate: null,
  father: null,
  mother: null,

};

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const isNotString = (param) => typeof param !== 'string';

const validateCredentials = ({
  horseName,
  ownerId,
  showName = null,
  genderId,
  breedId,
  colorId,
  disciplineId,
  microchipNumber = null,
  horseWeight = null,
  horseHeight = null,
  birthDate,
  father = null,
  mother = null,

}) => {
  if (isNotString(horseName) || horseName.length < 2) {
    throw new Error('Invalid Horse Name');
  }
  if (!validator.isInt(ownerId)) {
    throw new Error('Invalid Owner Id');
  }
  if (
    showName !== null && (isNotString(showName) || showName.length < 3)) {
    throw new Error('Invalid ShowName');
  }
  if (!validator.isInt(genderId)) {
    throw new Error('Invalid gender Id');
  }
  if (!validator.isInt(breedId)) {
    throw new Error('Invalid  breed Id');
  }
  if (!validator.isInt(colorId)) {
    throw new Error('Invalid color Id');
  }
  if (!validator.isInt(disciplineId)) {
    throw new Error('Invalid discipline Id');
  }
  if (microchipNumber !== null && !validator.isInt(microchipNumber)) {
    throw new Error('Invalid microchipNumber');
  }
  if (horseWeight !== null && !validator.isFloat(horseWeight)) {
    throw new Error('Invalid Horse Weight');
  }
  if (horseHeight !== null && !validator.isFloat(horseHeight)) {
    throw new Error('Invalid Horse Height');
  }
  if (isNotString(birthDate)) {
    throw new Error('Invalid birth Date');
  }
  if (
    father !== null && (isNotString(father) || father.length < 3)) {
    throw new Error('Invalid father Name');
  }
  if (
    mother !== null && (isNotString(mother) || mother.length < 3)) {
    throw new Error('Invalid mother Name');
  }

  horse = {
    horseName,
    ownerId,
    showName,
    genderId,
    breedId,
    colorId,
    disciplineId,
    microchipNumber,
    horseWeight,
    horseHeight,
    birthDate,
    father,
    mother,
  };
};

const postHorse = async (req, resp) => {
  try {
    if (req.body === undefined || req.body === null) {
      throw new Error('No data found');
    } else {
      validateCredentials(req.body);
      putHorse(horse)
        .then((values) => {
          resp.status(200).json({
            status: 200,
            data: {
              horseName: values.horse_name,
              ownerId: values.owner_id,
              showName: values.show_name,
              genderId: values.gender_id,
              breedId: values.breed_id,
              colorId: values.color_id,
              disciplineId: values.discipline_id,
              microchipNumber: values.microchip_number,
              horseWeight: values.horse_weight,
              horseHeight: values.horse_height,
              birthDate: values.birthdate,
              father: values.father,
              mother: values.mother,
            },
            error: null,
          });
        })
        .catch((err) => {
          returnError(err, resp);
        });
    }
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = postHorse;
