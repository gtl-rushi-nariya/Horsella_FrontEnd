const validator = require('validator');
const postUser = require('../../../utilities/db/user/postUser');
const { encryptPassword } = require('../../../utilities/bcryptUtils');
const getUserByEmail = require('../../../utilities/db/user/getUserByEmail');

let user = {
  id: null,
  firstname: null,
  middlename: null,
  lastname: null,
  email: null,
  phoneRegion: null,
  phoneNumber: null,
  country: null,
  role: null,
  password: null,
};

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const isNotString = (param) => typeof param !== 'string';

const validateCredentials = ({
  firstname, middlename = null, lastname, email, phoneRegion = null,
  phoneNumber = null, country = null, role, password,
}) => {
  if (isNotString(firstname) || firstname.length < 3) {
    throw new Error('Invalid Firstname');
  }
  if (middlename !== null && (isNotString(middlename) || middlename.length < 3)) {
    throw new Error('Invalid Middlename');
  }
  if (isNotString(lastname) || lastname.length < 3) {
    throw new Error('Invalid Lastname');
  }
  if (isNotString(email) || !validator.isEmail(email)) {
    throw new Error('Invalid Email id');
  }
  if (phoneRegion !== null
    && (isNotString(phoneRegion) || !validator.isIn(phoneRegion.toUpperCase(), ['IN', 'GB']))) {
    throw new Error('Invalid Phone Region');
  }
  if (phoneNumber !== null
    && (isNotString(phoneNumber)
    || (phoneRegion !== null
      ? !validator.isMobilePhone(phoneNumber, `en-${phoneRegion}`)
      : !validator.isMobilePhone(phoneNumber, 'en-IN')))) {
    throw new Error('Invalid Phone Number');
  }
  if (country !== null && (isNotString(country) || !validator.isIn(country.toLowerCase(), ['india']))) {
    throw new Error('Invalid Country');
  }
  if (isNotString(role) || !validator.isInt(role, { min: 1, max: 5 })) {
    throw new Error('Invalid User Type');
  }
  if (isNotString(password) || password.length < 8) {
    throw new Error('Invalid Password');
  }
  user = {
    firstname,
    middlename,
    lastname,
    email,
    phoneRegion,
    phoneNumber,
    country,
    role: parseInt(role, 10),
    password: encryptPassword(password),
  };
};

const registerUser = async (req, resp) => {
  try {
    if (req.body === undefined || req.body === null) {
      throw new Error('No data found');
    } else {
      validateCredentials(req.body);
      if (!await getUserByEmail({ email: user.email, password: req.body.password })) {
        postUser(user)
          .then((values) => {
            resp.status(201).json({
              status: 201,
              data: {
                name: `${values.first_name}${values.middle_name ? ` ${values.middle_name}` : ''} ${values.last_name}`,
                email: values.email,
                phoneNumber: values.phone_number,
                country: values.country,
                role: values.role,
              },
              error: null,
            });
          })
          .catch((err) => {
            returnError(err, resp);
          });
      } else {
        throw new Error('User already exists');
      }
    }
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = registerUser;
