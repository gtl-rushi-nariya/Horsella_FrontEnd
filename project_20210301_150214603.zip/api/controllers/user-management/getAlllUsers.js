const getAllUsers = (req, resp) => {
  console.log('In get Users');
  resp.json({
    data: 'In getUsers',
  });
};

module.exports = getAllUsers;
