const fetchAllUsers = require('../../../utilities/db/user/getAllUsers');

const getAllUsers = async (req, resp) => {
  try {
    fetchAllUsers()
      .then((users) => {
        resp.status(200).json(users);
      })
      .catch((err) => {
        throw new Error(err);
      });
  } catch (err) {
    resp.status(500).json(err.message);
  }
};

module.exports = getAllUsers;
