const checkIfUserExists = require('../../../utilities/db/user/checkIfUserExists');
const deactivateUser = require('../../../utilities/db/user/deleteUser');

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(500).json({
    status: 500,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const deleteUser = async (req, resp) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (await checkIfUserExists(id)) {
      deactivateUser(id)
        .then(() => {
          resp.status(204).send();
        })
        .catch((err) => {
          returnError(err, resp);
        });
    } else {
      returnError({ message: 'User does not exists' }, resp);
    }
  } catch (err) {
    returnError(err, resp);
  }
};

module.exports = deleteUser;
