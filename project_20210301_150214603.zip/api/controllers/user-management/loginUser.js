const validator = require('validator');
const getUserByEmail = require('../../../utilities/db/user/getUserByEmail');
const getUserRole = require('../../../utilities/db/user/getUserRole');
const { generateToken } = require('../../../utilities/jwtUtils');

let user = {
  id: null,
  email: null,
  password: null,
  role: null,
  token: null,
};

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(500).json({
    status: 500,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const validateCredentials = ({ email, password }) => {
  // Checking email address
  if (validator.isEmail(email)) {
    // Checking if password is passed or not
    if (!validator.isEmpty(password)) {
      // Set global user object
      user = { email, password };
    } else {
      throw new Error('Password is a required field');
    }
  } else {
    throw new Error('Invalid Email Id');
  }
};

const login = (req, resp) => {
  try {
    if (req.body === undefined || req.body === null) {
      throw new Error('No data found');
    } else {
      validateCredentials(req.body);
      getUserByEmail(user)
        .then((userCreds) => {
          if (userCreds != null) {
            console.log(userCreds);
            user.id = userCreds.id;
            user.token = generateToken(user);
            getUserRole(user.id)
              .then((role) => {
                user.role = role;
                resp.status(200).json({
                  status: 200,
                  data: {
                    email: user.email,
                    role: user.role,
                    token: user.token,
                  },
                  error: null,
                });
              })
              .catch((err) => {
                returnError(err, resp);
              });
          } else {
            returnError({ message: 'Invalid email or password' }, resp);
          }
        })
        .catch((err) => {
          returnError(err, resp);
        });
    }
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = login;
