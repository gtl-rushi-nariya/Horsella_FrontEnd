const getUser = require('../../../utilities/db/user/getUserById');

const returnError = (err, resp) => {
  resp.status(500).json(err.message);
};

const getUserById = (req, resp) => {
  try {
    const { id } = req.params;
    getUser(id)
      .then((user) => {
        resp.status(200).json(user);
      })
      .catch((err) => {
        returnError(err, resp);
      });
  } catch (err) {
    returnError(err, resp);
  }
};

module.exports = getUserById;
