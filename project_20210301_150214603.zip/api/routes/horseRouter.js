const express = require('express');
const { ensureToken } = require('../../utilities/jwtUtils');

const getHorseById = require('../controllers/horse-management/getHorseById');
const getHorseByUserId = require('../controllers/horse-management/getHorseByUserId');
const getAllHorses = require('../controllers/horse-management/getAllHorses');
const postHorse = require('../controllers/horse-management/postHorse');
const updateHorse = require('../controllers/horse-management/updateHorse');
const deleteHorse = require('../controllers/horse-management/deleteHorse');
const getAllSellingHorses = require('../controllers/horse-management/selling/getAllSellingHorses');
const getAllSellingHorsesByUser = require('../controllers/horse-management/selling/getAllSellingHorseByUser');
const registerHorseForSale = require('../controllers/horse-management/selling/registerHorseForSale');
const updateHorseSold = require('../controllers/horse-management/selling/updateHorseSold');

const router = express.Router();

// Applying middleware to the whole router
// router.use(ensureToken);

// To get all horses for a specific user
//* User Id will be available in req.userId field
// GET: localhost:3000/api/horse/list
router.get('/list', (req, resp) => getHorseByUserId(req, resp));

// To get all the horses
// GET: localhost:3000/api/horse/all
router.get('/all', (req, resp) => getAllHorses(req, resp));

// POST: localhost:3000/api/horse/add
router.post('/add', (req, resp) => postHorse(req, resp));

// PATCH: localhost:3000/api/horse/update/:id
router.patch('/update/:id', (req, resp) => updateHorse(req, resp));

// DELETE: localhost:3000/api/horse/delete/:id
router.delete('/delete/:id', (req, resp) => deleteHorse(req, resp));

// GET: localhost:3000/api/horse/selling/all
router.get('/selling/all', (req, resp) => getAllSellingHorses.js(req, resp));

// GET: localhost:3000/api/horse/my-selling-horses
router.get('/my-horses-for-sale', (req, resp) => getAllSellingHorsesByUser(req, resp));

// POST: localhost:3000/api/horse/sell-horse/:horseId
router.post('/sell-horse/:horseId', (req, resp) => registerHorseForSale(req, resp));

// PUT: localhost:3000/api/horse/update-horse-sold/:saleId
router.put('/update-horse-sold/:saleId', (req, resp) => updateHorseSold(req, resp));

// GET: localhost:3000/api/horse/:id
router.get('/:id', (req, resp) => getHorseById(req, resp));

module.exports = router;
