const express = require('express');
const { ensureToken } = require('../../utilities/jwtUtils');

const login = require('../controllers/user-management/loginUser');
const getAllUsers = require('../controllers/user-management/getAllUsers');
const registerUser = require('../controllers/user-management/registerUser');
const updateUser = require('../controllers/user-management/updateUser');
const deleteUser = require('../controllers/user-management/deleteUser');
const getUserById = require('../controllers/user-management/getUserById');

const router = express.Router();

router.post('/login', (req, resp) => login(req, resp));
router.get('/:id', ensureToken, (req, resp) => getUserById(req, resp));
router.get('/all', ensureToken, (req, resp) => getAllUsers(req, resp));
router.post('/register', ensureToken, (req, resp) => registerUser(req, resp));
router.patch('/update/:id', ensureToken, (req, resp) => updateUser(req, resp));
router.delete('/delete/:id', ensureToken, (req, resp) => deleteUser(req, resp));

module.exports = router;
