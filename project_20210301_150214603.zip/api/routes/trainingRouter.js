const express = require('express');
const { ensureToken } = require('../../utilities/jwtUtils');

const getTrainingCenterById = require('../controllers/training-management/getTrainingCenterById');
const getAllTrainingCenters = require('../controllers/training-management/getAllTrainingCenters');
const postTrainingCenter = require('../controllers/training-management/postTrainingCenter');
const updateTrainingCenter = require('../controllers/training-management/updateTrainingCenter');
const deleteTrainingCenter = require('../controllers/training-management/deleteTrainingCenter');

const router = express.Router();

// Applying middleware to the whole router
// router.use(ensureToken);

// GET: localhost:3000/api/training-center/all
router.get('/all', (req, resp) => getAllTrainingCenters(req, resp));

// GET: localhost:3000/api/training-center/:id
router.get('/:id', (req, resp) => getTrainingCenterById(req, resp));

// POST: localhost:3000/api/training-center/add
router.post('/add', (req, resp) => postTrainingCenter(req, resp));

// PATCH: localhost:3000/api/training-center/update/:id
router.put('/update/:id', (req, resp) => updateTrainingCenter(req, resp));

// DELETE: localhost:3000/api/training-center/delete/:id
router.delete('/delete/:id', (req, resp) => deleteTrainingCenter(req, resp));

module.exports = router;
