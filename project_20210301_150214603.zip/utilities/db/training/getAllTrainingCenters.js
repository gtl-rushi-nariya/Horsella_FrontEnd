const runQuery = require('../dbconn');

const getTrainingCenters = () => new Promise((resolve, reject) => {
  const selectTrainingCenterQuery = `SELECT * FROM training_centers WHERE is_active= ${true} ORDER BY id ASC`;

  runQuery(selectTrainingCenterQuery)
    .then((response) => {
      let imageName;

      const trainingCenters = response.rows.map((trainingCenter) => {
        imageName = trainingCenter.image_path;
        // eslint-disable-next-line no-param-reassign
        trainingCenter.image_path = `http://localhost:3000/public/images/${imageName}`;
        return trainingCenter;
      });

      response.rows = [...trainingCenters];

      console.log(response.rows);
      resolve(response.rows);
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = getTrainingCenters;
