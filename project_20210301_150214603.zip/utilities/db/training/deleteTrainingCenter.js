const runQuery = require('../dbconn');

const deleteTrainingCenter = async (centerId) => new Promise((resolve, reject) => {
  const query = `UPDATE training_centers SET is_active = false WHERE id = ${centerId}`;
  runQuery(query)
    .then((result) => {
      if (result != null && result.rowCount === 1) {
        resolve();
      } else {
        reject();
      }
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = deleteTrainingCenter;
