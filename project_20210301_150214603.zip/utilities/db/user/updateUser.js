const runQuery = require('../dbconn');
const getUserById = require('./getUserById');
const getUserRole = require('./getUserRole');

const buildUpdateQuery = (updatedUser) => {
  let updateUsersQuery = 'UPDATE users SET ';
  let updateLoginQuery = 'UPDATE login SET ';
  if (updatedUser.firstname != null) {
    updateUsersQuery += `first_name = '${updatedUser.firstname}', `;
  }
  if (updatedUser.middlename != null) {
    updateUsersQuery += `middle_name = '${updatedUser.middlename}', `;
  }
  if (updatedUser.lastname != null) {
    updateUsersQuery += `last_name = '${updatedUser.lastname}', `;
  }
  if (updatedUser.email != null) {
    updateLoginQuery += `email = '${updatedUser.email}', `;
  }
  if (updatedUser.phoneRegion != null) {
    updateUsersQuery += `phone_region = '${updatedUser.phoneRegion}', `;
  }
  if (updatedUser.phoneNumber != null) {
    updateUsersQuery += `phone_number = '${updatedUser.phoneNumber}', `;
  }
  if (updatedUser.country != null) {
    updateUsersQuery += `country = '${updatedUser.country}', `;
  }
  if (updatedUser.role != null) {
    updateUsersQuery += `user_role = ${updatedUser.role}, `;
  }
  if (updatedUser.password != null) {
    updateLoginQuery += `user_password = '${updatedUser.password}' `;
  }
  updateUsersQuery += `updated_at = '${new Date().toISOString()}' WHERE id = ${updatedUser.id}`;
  updateLoginQuery += `WHERE id = ${updatedUser.id}`;
  updateLoginQuery = updateLoginQuery.replace(', WHERE', ' WHERE');
  return { updateUsersQuery, updateLoginQuery };
};

const patchUser = (updatedUser) => new Promise((resolve, reject) => {
  const { updateUsersQuery, updateLoginQuery } = buildUpdateQuery(updatedUser);
  console.log(updateUsersQuery);
  console.log(updateLoginQuery);
  runQuery(updateUsersQuery)
    .then(() => {
      if (updatedUser.email != null || updatedUser.password != null) {
        runQuery(updateLoginQuery)
          .then(() => {
            getUserById(updatedUser.id)
              .then((output) => {
                resolve(output);
              })
              .catch((err) => {
                reject(err);
              });
          })
          .catch((err) => {
            reject(err);
          });
      } else {
        getUserById(updatedUser.id)
          .then((output) => {
            resolve(output);
          })
          .catch((err) => {
            reject(err);
          });
      }
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = patchUser;
