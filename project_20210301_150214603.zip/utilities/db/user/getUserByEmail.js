const runQuery = require('../dbconn');
const { comparePassword } = require('../../bcryptUtils');

const getUserByEmail = async ({ email, password }) => new Promise((resolve, reject) => {
  const query = `SELECT id, email, user_password FROM login WHERE email = '${email}' AND is_active = true`;
  runQuery(query)
    .then((result) => {
      if (result.rowCount === 1 && comparePassword(password, result.rows[0].user_password)) {
        resolve(result.rows[0]);
      }
      resolve(null);
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = getUserByEmail;
