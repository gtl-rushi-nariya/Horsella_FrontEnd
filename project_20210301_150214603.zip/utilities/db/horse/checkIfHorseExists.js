const runQuery = require('../dbconn');

const checkIfHorseExists = (id) => new Promise((resolve, reject) => {
  const query = `SELECT id FROM horses WHERE id = ${id} AND is_active=TRUE`;
  runQuery(query)
    .then((response) => {
      if (response.rowCount === 1) {
        resolve(true);
      }
      resolve(false);
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = checkIfHorseExists;
