const runQuery = require('../dbconn');

const getHorseByUserIdDb = (id) => new Promise((resolve, reject) => {
  const selectHorseByUserIdQuery = `SELECT * FROM horses WHERE owner_id = ${id} AND is_active=TRUE`;
  runQuery(selectHorseByUserIdQuery)
    .then((response) => {
      resolve(response.rows);
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = getHorseByUserIdDb;
