const runQuery = require('../dbconn');

const getHorseByIdDb = (id) => new Promise((resolve, reject) => {
  const selectHorseByIdQuery = `SELECT * FROM horses WHERE id = ${id} AND is_active=TRUE`;
  runQuery(selectHorseByIdQuery)
    .then((response) => {
      if (response.rowCount === 1) {
        resolve(response.rows[0]);
      }
      reject(new Error('Invalid Horse Id'));
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = getHorseByIdDb;
