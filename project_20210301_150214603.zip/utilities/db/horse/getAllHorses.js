const runQuery = require('../dbconn');

const getHorses = () => new Promise((resolve, reject) => {
  const selectHorseQuery = 'SELECT * FROM horses WHERE is_active = true';
  runQuery(selectHorseQuery)
    .then((response) => {
      resolve(response.rows);
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = getHorses;
