const runQuery = require('../../dbconn');

const getAllSellingHorseByUser = (userId) => new Promise((resolve, reject) => {
  const query = `SELECT id, race_id, horse_id, price FROM sales WHERE is_active = true AND user_id = ${userId}`;
  runQuery(query)
    .then((result) => {
      resolve(result);
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = getAllSellingHorseByUser;
