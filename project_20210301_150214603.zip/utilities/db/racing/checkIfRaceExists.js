const runQuery = require('../dbconn');

const checkIfRaceExists = (id) => new Promise((resolve, reject) => {
  const query = `SELECT id FROM races WHERE id = ${id} AND is_cancelled=FALSE`;
  runQuery(query)
    .then((response) => {
      if (response.rowCount === 1) {
        resolve(true);
      }
      resolve(false);
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = checkIfRaceExists;
