/**
 * Dependency Imports
 */
const express = require("express");
const createError = require("http-errors");
const path = require("path");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
const HttpStatusCode = require("http-status-codes");
const i18n = require("i18n-2");
const lcid = require("lcid");
const dotenv = require("dotenv");
const { createServer } = require("http");
const cors = require("cors");
//const multer = require("multer");

/**
 * File Imports
 */
const userRouter = require("./api/routes/userRouter");
const horseRouter = require("./api/routes/horseRouter");
const breedingRouter = require("./api/routes/breedingRouter");
const racingRouter = require("./api/routes/racingRouter");
const trainingRouter = require("./api/routes/trainingRouter");

/**
 * Instantiating app
 */
const app = express();

/**
 * Configuring Localization
 */
i18n.expressBind(app, {
  locales: ["en-us", "sv-se", "da-dk"],
  extension: ".json",
  defaultLocale: "en-us",
});

/**
 * Normalizing Port Value
 */
const normalizePort = (val) => {
  const Port = parseInt(val, 10);

  if (Number.isNaN(Port)) {
    // Named pipe
    return val;
  }

  if (Port >= 0) {
    // Port number
    return Port;
  }

  return false;
};

/**
 * Configuring app
 */
const port = normalizePort(process.env.PORT);
app.use(cors());
app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use("/public", express.static("./public"));

// This is how we set a locale from req.cookies.
app.use((req, res, next) => {
  let lang = 1033;
  let file = "";
  if (req.headers["accept-language"] === "1053") {
    lang = 1053;
  } else if (req.headers["accept-language"] === "1030") {
    lang = 1030;
  }
  file = lcid.from(lang);
  file = file.replace("_", "-").toLowerCase();
  req.i18n.setLocale(file);
  next();
});

// Locale error handler
app.use((err, req, res, next) => {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = err.app.get("env") === "development" ? err : {};

  // render the error page
  res.status(err.status || HttpStatusCode.StatusCodes.INTERNAL_SERVER_ERROR);
  res.json({
    error: err,
  });
});

/**
 * Setting Routes
 */
app.use("/api/user/", userRouter);
app.use("/api/horse/", horseRouter);
app.use("/api/breeding-center/", breedingRouter);
app.use("/api/training-center/", trainingRouter);
app.use("/api/race/", racingRouter);

/**
 * Homepage
 */
app.get("/", (req, resp) => {
  resp.send("Welcome to home page");
});

/**
 * Serving Static Assets
 */
app.use(
  "/images/horse",
  express.static(path.join(__dirname, "public/images/horse"))
);
app.use(
  "/images/user",
  express.static(path.join(__dirname, "public/images/user"))
);

/**
 * Catching 404 requests
 */
app.use((req, resp, next) => {
  resp.status(404).json({
    status: 404,
    error: {
      message: "Page not found",
    },
    data: null,
  });
});

/**
 * Starting Server
 */
const server = createServer(app);
server.listen(port);

/**
 * Server Event Handling
 */
server.on("error", (error) => {
  if (error.syscall !== "listen") {
    throw error;
  }

  const bind = typeof port === "string" ? `Pipe ${port}` : `Port ${port}`;

  // Handle specific listen errors with friendly messages
  switch (error.code) {
    case "EACCES":
      console.error(`${bind} requires elevated privileges`);
      process.exit(1);
      break;
    case "EADDRINUSE":
      console.error(`${bind} is already in use`);
      process.exit(1);
      break;
    default:
      throw error;
  }
});

server.on("listening", () => {
  const addr = server.address();
  const uri = typeof addr === "string" ? addr : `http://localhost:${addr.port}`;
  console.log(`Listening on ${uri}`);
});
