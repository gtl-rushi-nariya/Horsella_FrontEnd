const runQuery = require("../dbconn");

const buildInsertQuery = (newTrainigCenter) => {
  let fields = "";
  let values = "";
  //----------------------
  fields += "center_name, ";
  values += `'${newTrainigCenter.centerName}', `;
  //----------------------
  fields += "owner_name, ";
  values += `'${newTrainigCenter.ownerName}', `;
  //-----------------------
  fields += "description, ";
  values += `'${newTrainigCenter.description}', `;
  //---------------------
  if (newTrainigCenter.experience != null) {
    fields += "experience, ";
    values += `'${newTrainigCenter.experience}', `;
  }
  //----------------------
  fields += "address, ";
  values += `'${newTrainigCenter.address}', `;
  //----------------------
  fields += "email, ";
  values += `'${newTrainigCenter.email}', `;
  //----------------------
  if (newTrainigCenter.website != null) {
    fields += "website, ";
    values += `'${newTrainigCenter.website}', `;
  }
  //----------------------
  fields += "contact, ";
  values += `'${newTrainigCenter.contact}', `;
  //---------------------
  if (newTrainigCenter.workingHours != null) {
    fields += "working_hours, ";
    values += `'${newTrainigCenter.workingHours}', `;
  }
  //------------------------
  if (newTrainigCenter.imagePath != null) {
    fields += "image_path, ";
    values += `'${newTrainigCenter.imagePath}', `;
  }
  //------------------------

  fields += "is_active, created_at, updated_at";
  values += `${true}, '${new Date().toISOString()}', '${new Date().toISOString()}'`;

  return `INSERT INTO training_centers (${fields}) VALUES (${values}) 
    RETURNING id, center_name, owner_name, description, address, email, contact, image_path`;
};

const CreateTrainingCenter = (newTrainigCenter) =>
  new Promise((resolve, reject) => {
    const insertUserQuery = buildInsertQuery(newTrainigCenter);
    //console.log(newTrainigCenter);
    runQuery(insertUserQuery)
      .then((trainigCenter) => {
        const output = {
          id: trainigCenter.rows[0].id,
          centerName: trainigCenter.rows[0].center_name,
          ownerName: trainigCenter.rows[0].owner_name,
          contact: trainigCenter.rows[0].contact,
          email: trainigCenter.rows[0].email,
          address: trainigCenter.rows[0].address,
          imagePath: trainigCenter.rows[0].image_path,
        };
        resolve(output);
      })
      .catch((err) => {
        reject(err);
      });
  });

module.exports = CreateTrainingCenter;
