const { response } = require("express");
const runQuery = require("../dbconn");

const buildUpdateQuery = (updatedTrainigCenter, id) => {
  return `update training_centers set center_name = '${
    updatedTrainigCenter.centerName
  }', owner_name = '${updatedTrainigCenter.ownerName}', description = '${
    updatedTrainigCenter.description
  }', experience= '${updatedTrainigCenter.experience}',
    address = '${updatedTrainigCenter.address}', email = '${
    updatedTrainigCenter.email
  }', website = '${updatedTrainigCenter.website}', contact = '${
    updatedTrainigCenter.contact
  }', working_hours = '${updatedTrainigCenter.workingHours}', image_path='${
    updatedTrainigCenter.imagePath
  }', is_active=${true} where id = ${id}
    RETURNING id, center_name, owner_name, description, address, email, contact, image_path`;
};

const putTrainingCenter = (updatedTrainigCenter, id) =>
  new Promise((resolve, reject) => {
    const checkCenterQuery = `select * from training_centers where id = ${id}`;
    runQuery(checkCenterQuery)
      .then((response) => {
        if (response.rows[0] != null) {
          const updateCenterQuery = buildUpdateQuery(updatedTrainigCenter, id);
          console.log(updatedTrainigCenter);
          return runQuery(updateCenterQuery);
        } else {
          throw new Error("Training center not found.");
        }
      })
      .then((trainigCenter) => {
        const output = {
          id: trainigCenter.rows[0].id,
          centerName: trainigCenter.rows[0].center_name,
          ownerName: trainigCenter.rows[0].owner_name,
          contact: trainigCenter.rows[0].contact,
          email: trainigCenter.rows[0].email,
          address: trainigCenter.rows[0].address,
          imagePath: trainigCenter.rows[0].image_path,
        };
        resolve(output);
      })
      .catch((err) => {
        reject(err);
      });
  });

module.exports = putTrainingCenter;
