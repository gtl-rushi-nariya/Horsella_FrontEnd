const runQuery = require("../dbconn");

const getTrainingCenterByIdDb = (id) =>
  new Promise((resolve, reject) => {
    const selectTrainingCenterByIdQuery = `select * from training_centers where id = ${id} and is_active = ${true}`;

    runQuery(selectTrainingCenterByIdQuery)
      .then((response) => {
        if (response.rows[0] != null) {
          const imageName = response.rows[0].image_path;
          response.rows[0].image_path =
            "http://localhost:3000/public/images/" + imageName;
          console.log(response.rows);
        }

        resolve(response.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
  });

module.exports = getTrainingCenterByIdDb;
