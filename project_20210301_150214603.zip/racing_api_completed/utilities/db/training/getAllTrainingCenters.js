const runQuery = require("../dbconn");

const getTrainingCenters = () =>
  new Promise((resolve, reject) => {
    const selectTrainingCenterQuery = `select * from training_centers where is_active= ${true}`;

    runQuery(selectTrainingCenterQuery)
      .then((response) => {
        let imageName;

        const trainingCenters = response.rows.map((trainingCenter) => {
          imageName = trainingCenter.image_path;
          trainingCenter.image_path =
            "http://localhost:3000/public/images/" + imageName;
          return trainingCenter;
        });

        response.rows = [...trainingCenters];

        console.log(response.rows);
        resolve(response.rows);
      })
      .catch((err) => {
        reject(err);
      });
  });

module.exports = getTrainingCenters;
