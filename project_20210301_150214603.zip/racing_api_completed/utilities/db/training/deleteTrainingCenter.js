const runQuery = require("../dbconn");

const deleteTrainingCenterById = (id) =>
  new Promise((resolve, reject) => {
    const checkCenterQuery = `select * from training_centers where id = ${id}`;
    runQuery(checkCenterQuery)
      .then((response) => {
        if (response.rows[0] != null) {
          const selectTrainingCenterByIdQuery = `update training_centers set  is_active = ${false} where id = ${id}
            RETURNING id, center_name, owner_name, description, address, email, is_active`;
          return runQuery(selectTrainingCenterByIdQuery);
        } else {
          throw new Error("Training center not found.");
        }
      })
      .then((response) => {
        const output = {
          id: response.rows[0].id,
          centerName: response.rows[0].center_name,
          ownerName: response.rows[0].owner_name,
          email: response.rows[0].email,
          isActive: response.rows[0].is_active,
        };
        console.log(output);
        resolve(output);
      })
      .catch((err) => {
        reject(err);
      });
  });

module.exports = deleteTrainingCenterById;
