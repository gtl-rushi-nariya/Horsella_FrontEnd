const runQuery = require('../dbconn');
const { comparePassword } = require('../../bcryptUtils');

const getUserByEmail = async ({ email, password }) => new Promise((resolve, reject) => {
  const query = `SELECT id, email, pass FROM login WHERE email = '${email}'`;
  runQuery(query)
    .then((result) => {
      if (result.rowCount === 1 && comparePassword(password, result.rows[0].pass)) {
        resolve(result.rows[0]);
      }
      resolve(null);
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = getUserByEmail;
