const runQuery = require('../dbconn');

const buildUpdateQuery = (updatedUser) => {
  // UPDATE TABLE table_name SET field1=value1, field2=value2 WHERE id = id;
  let updateQuery = 'UPDATE TABLE users SET ';
  if (updatedUser.first_name != null) {
    updateQuery += `first_name = '${updatedUser.first_name}', `;
  }
  if (updatedUser.middle_name != null) {
    updateQuery += `middle_name = '${updatedUser.middle_name}', `;
  }
  if (updatedUser.last_name != null) {
    updateQuery += `last_name = '${updatedUser.last_name}', `;
  }
  if (updatedUser.email_id != null) {
    updateQuery += `email_id = '${updatedUser.email_id}', `;
  }
  if (updatedUser.phone_region != null) {
    updateQuery += `phone_region = '${updatedUser.phone_region}', `;
  }
  if (updatedUser.phone_number != null) {
    updateQuery += `phone_number = '${updatedUser.phone_number}', `;
  }
  if (updatedUser.country != null) {
    updateQuery += `country = '${updatedUser.country}', `;
  }
  if (updatedUser.type != null) {
    updateQuery += `type = ${updatedUser.type}, `;
  }
  updateQuery += `updated_at = '${new Date().toISOString()}' WHERE id = ${updatedUser.id} 
    RETURNING first_name, middle_name, last_name, email_id, phone_region, phone_number, country, type`;
  return updateQuery;
};

const patchUser = (updatedUser) => {
  const updateQuery = buildUpdateQuery(updatedUser);
  console.log(updatedUser);
  console.log(updateQuery);
  return 'Hello';
};

module.exports = patchUser;
