const runQuery = require('../dbconn');
const getUserRole = require('./getUserRole');

const buildInsertQuery = (newUser) => {
  let fields = '';
  let values = '';
  fields += 'first_name, ';
  values += `'${newUser.firstname}', `;
  if (newUser.middlename != null) {
    fields += 'middle_name,';
    values += `'${newUser.middlename}', `;
  }
  fields += 'last_name, ';
  values += `'${newUser.lastname}', `;
  fields += 'email_id, ';
  values += `'${newUser.email}', `;
  if (newUser.phoneRegion != null) {
    fields += 'phone_region, ';
    values += `'${newUser.phoneRegion}', `;
  }
  if (newUser.phoneNumber != null) {
    fields += 'phone_number, ';
    values += `'${newUser.phoneNumber}', `;
  }
  if (newUser.country != null) {
    fields += 'country, ';
    values += `'${newUser.country}', `;
  }
  fields += 'type, is_active, created_at, updated_at';
  values += `${newUser.type}, ${true}, '${new Date().toISOString()}', '${new Date().toISOString()}'`;
  return `INSERT INTO users (${fields}) VALUES (${values}) 
  RETURNING id, first_name, middle_name, last_name, email_id, phone_region, phone_number, country, type`;
};

const postUser = (newUser) => new Promise((resolve, reject) => {
  const insertUserQuery = buildInsertQuery(newUser);
  const insertUserLoginQuery = `INSERT INTO login (email, pass)
    VALUES ('${newUser.email}', '${newUser.password}')`;
  runQuery(insertUserQuery)
    .then((user) => {
      const output = {
        id: user.rows[0].id,
        first_name: user.rows[0].first_name,
        middle_name: user.rows[0].middle_name,
        last_name: user.rows[0].last_name,
        email_id: user.rows[0].email_id,
        phone_region: user.rows[0].phone_region,
        phone_number: user.rows[0].phone_number,
        country: user.rows[0].country,
        role: null,
      };
      runQuery(insertUserLoginQuery)
        .then(() => {
          getUserRole(output.id)
            .then((userRole) => {
              output.role = userRole.role;
              resolve(output);
            })
            .catch((err) => {
              reject(err);
            });
        })
        .catch((err) => {
          reject(err);
        });
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = postUser;
