const runQuery = require('../dbconn');

const getUserRole = (userId) => new Promise((resolve, reject) => {
  const query = `SELECT role FROM users INNER JOIN roles ON users.type = roles.id AND users.id = '${userId}'`;
  runQuery(query)
    .then((result) => {
      if (result.rowCount === 1) {
        resolve(result.rows[0]);
      } else {
        reject(new Error('Invalid User Role'));
      }
    })
    .catch((err) => {
      reject(err);
    });
});

module.exports = getUserRole;
