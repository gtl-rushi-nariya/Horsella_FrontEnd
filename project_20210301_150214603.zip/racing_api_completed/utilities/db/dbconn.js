const { Pool } = require("pg");

/* const pool = new Pool({
  connectionString: process.env.DATABASE_URL, // DATABASE_URL is set in Heroku Environment variables
}); */

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_DATABASE,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

const runQuery = async (query) =>
  new Promise((resolve, reject) => {
    pool
      .query(query)
      .then((result) => {
        resolve(result);
      })
      .catch((err) => {
        reject(err);
      });
  });

module.exports = runQuery;
