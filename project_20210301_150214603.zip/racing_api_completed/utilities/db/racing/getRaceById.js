const runQuery = require("../dbconn");

const getRaceByIdDb = (id) =>
  new Promise((resolve, reject) => {
    const selectRaceByIdQuery = `select * from races where id = ${id} and is_cancelled = ${false}`;

    runQuery(selectRaceByIdQuery)
      .then((response) => {
        resolve(response.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
  });

module.exports = getRaceByIdDb;
