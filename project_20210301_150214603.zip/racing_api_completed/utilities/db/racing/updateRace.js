const { response } = require("express");
const runQuery = require("../dbconn");

// id,
// raceName,
// racecourse,
// RaceDate,
// raceLength,
// raceHorseAgeCriteria,
// RaceHorseWeightCriteria,

const buildUpdateQuery = (updatedRace, id) => {
  return `update races set race_name = '${
    updatedRace.raceName
  }', racecourse = '${updatedRace.racecourse}', race_date = '${
    updatedRace.RaceDate
  }', race_length = '${updatedRace.raceLength}', racehorse_age_criteria = '${
    updatedRace.raceHorseAgeCriteria
  }', racehorse_weight_criteria = '${
    updatedRace.RaceHorseWeightCriteria
  }', is_cancelled = '${false}', is_completed= '${false}' where id = ${id}
  RETURNING id, race_name, racecourse, race_date, racehorse_age_criteria`;
};

const putRace = (updatedRace, id) =>
  new Promise((resolve, reject) => {
    const checkRaceQuery = `select * from races where id = ${id}`;
    runQuery(checkRaceQuery)
      .then((response) => {
        if (response.rows[0] != null) {
          const updateRaceQuery = buildUpdateQuery(updatedRace, id);
          console.log(updatedRace);
          return runQuery(updateRaceQuery);
        } else {
          throw new Error("Race not found.");
        }
      })
      .then((race) => {
        const output = {
          id: race.rows[0].id,
          raceName: race.rows[0].race_name,
          racecourse: race.rows[0].racecourse,
          RaceDate: race.rows[0].race_date,
          raceHorseAgeCriteria: race.rows[0].raceHorseAgeCriteria,
        };
        resolve(output);
      })
      .catch((err) => {
        reject(err);
      });
  });

module.exports = putRace;
