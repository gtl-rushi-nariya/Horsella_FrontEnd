const runQuery = require("../dbconn");

// id,
// raceName,
// racecourse,
// RaceDate,
// raceLength,
// raceHorseAgeCriteria,
// RaceHorseWeightCriteria,

const buildInsertQuery = (newRace) => {
  let fields = "";
  let values = "";
  //----------------------
  fields += "race_name, ";
  values += `'${newRace.raceName}', `;
  //----------------------
  fields += "racecourse, ";
  values += `'${newRace.racecourse}', `;
  //-----------------------
  fields += "race_date, ";
  values += `'${newRace.RaceDate}', `;
  //----------------------
  fields += "race_length, ";
  values += `'${newRace.raceLength}', `;
  //----------------------
  fields += "racehorse_age_criteria, ";
  values += `${newRace.raceHorseAgeCriteria}, `;
  //----------------------
  fields += "racehorse_weight_criteria, ";
  values += `'${newRace.RaceHorseWeightCriteria}', `;
  //---------------------

  fields += "is_cancelled, is_completed , created_at, updated_at";
  values += `${false}, ${false}, '${new Date().toISOString()}', '${new Date().toISOString()}'`;

  return `INSERT INTO races (${fields}) VALUES (${values}) 
    RETURNING id, race_name, racecourse, race_date, racehorse_age_criteria`;
};

const CreateRace = (newRace) =>
  new Promise((resolve, reject) => {
    const insertRaceQuery = buildInsertQuery(newRace);
    console.log(newRace);
    runQuery(insertRaceQuery)
      .then((race) => {
        const output = {
          id: race.rows[0].id,
          raceName: race.rows[0].race_name,
          racecourse: race.rows[0].racecourse,
          RaceDate: race.rows[0].race_date,
          raceHorseAgeCriteria: race.rows[0].raceHorseAgeCriteria,
        };
        resolve(output);
      })
      .catch((err) => {
        reject(err);
      });
  });

module.exports = CreateRace;
