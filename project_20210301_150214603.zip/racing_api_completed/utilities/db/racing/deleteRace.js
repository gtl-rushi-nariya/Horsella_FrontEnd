const runQuery = require("../dbconn");

const deleteRaceById = (id) =>
  new Promise((resolve, reject) => {
    const checkRaceQuery = `select * from races where id = ${id}`;
    runQuery(checkRaceQuery)
      .then((response) => {
        if (response.rows[0] != null) {
          const selectRaceByIdQuery = `update races set is_cancelled = ${true} where id = ${id}
          RETURNING id, race_name, racecourse, race_date, racehorse_age_criteria, is_cancelled`;
          return runQuery(selectRaceByIdQuery);
        } else {
          throw new Error("Race not found.");
        }
      })
      .then((race) => {
        const output = {
          id: race.rows[0].id,
          raceName: race.rows[0].race_name,
          racecourse: race.rows[0].racecourse,
          RaceDate: race.rows[0].race_date,
          raceHorseAgeCriteria: race.rows[0].raceHorseAgeCriteria,
          isCancelled: race.rows[0].is_cancelled,
        };
        console.log(output);
        resolve(output);
      })
      .catch((err) => {
        reject(err);
      });
  });

module.exports = deleteRaceById;
