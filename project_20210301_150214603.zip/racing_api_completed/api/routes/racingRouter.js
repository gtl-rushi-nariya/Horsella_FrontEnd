const express = require("express");
const { ensureToken } = require("../../utilities/jwtUtils");

const getRaceById = require("../controllers/racing-management/getRaceById");
const getAllRaces = require("../controllers/racing-management/getAllRaces");
const postRace = require("../controllers/racing-management/postRace");
const updateRace = require("../controllers/racing-management/updateRace");
const deleteRace = require("../controllers/racing-management/deleteRace");

const router = express.Router();

// Applying middleware to the whole router
// router.use(ensureToken);

// GET: localhost:3000/api/race/all
router.get("/all", (req, resp) => getAllRaces(req, resp));

// GET: localhost:3000/api/race/:id
router.get("/:id", (req, resp) => getRaceById(req, resp));

// POST: localhost:3000/api/race/add
router.post("/post", (req, resp) => postRace(req, resp));

// PATCH: localhost:3000/api/race/update/:id
router.put("/update/:id", (req, resp) => updateRace(req, resp));

// DELETE: localhost:3000/api/race/delete/:id
router.delete("/delete/:id", (req, resp) => deleteRace(req, resp));

module.exports = router;
