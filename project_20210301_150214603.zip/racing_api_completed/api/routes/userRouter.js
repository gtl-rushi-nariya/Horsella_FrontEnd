const express = require('express');
const { ensureToken } = require('../../utilities/jwtUtils');

const login = require('../controllers/user-management/loginUser');
const getAllUsers = require('../controllers/user-management/getAlllUsers');
const registerUser = require('../controllers/user-management/registerUser');
const updateUser = require('../controllers/user-management/updateUser');
const deleteUser = require('../controllers/user-management/deleteUser');

const router = express.Router();

router.post('/login', (req, resp) => login(req, resp));
router.get('/all', ensureToken, (req, resp) => getAllUsers(req, resp));
router.post('/register', (req, resp) => registerUser(req, resp));
router.patch('/update', ensureToken, (req, resp) => updateUser(req, resp));
router.delete('/delete', ensureToken, (req, resp) => deleteUser(req, resp));

module.exports = router;
