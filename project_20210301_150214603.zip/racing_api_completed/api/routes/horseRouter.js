const express = require('express');
const { ensureToken } = require('../../utilities/jwtUtils');

const getHorseById = require('../controllers/horse-management/getHorseById');
const getHorseByUserId = require('../controllers/horse-management/getHorseByUserId');
const getAllHorses = require('../controllers/horse-management/getAllHorses');
const postHorse = require('../controllers/horse-management/postHorse');
const updateHorse = require('../controllers/horse-management/updateHorse');
const deleteHorse = require('../controllers/horse-management/deleteHorse');

const router = express.Router();

// Applying middleware to the whole router
router.use(ensureToken);

// GET: localhost:3000/api/horse/:id
router.get('/:id', (req, resp) => getHorseById(req, resp));

// To get all horses for a specific user
//* User Id will be available in req.userId field
// GET: localhost:3000/api/horse/list
router.get('/list', (req, resp) => getHorseByUserId(req, resp));

// To get all the horses
// GET: localhost:3000/api/horse/all
router.get('/all', (req, resp) => getAllHorses(req, resp));

// POST: localhost:3000/api/horse/add
router.post('/add', (req, resp) => postHorse(req, resp));

// PATCH: localhost:3000/api/horse/update/:id
router.patch('/update/:id', (req, resp) => updateHorse(req, resp));

// DELETE: localhost:3000/api/horse/delete/:id
router.delete('/delete/:id', (req, resp) => deleteHorse(req, resp));

module.exports = router;
