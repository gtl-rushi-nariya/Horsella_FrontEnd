const deleteUser = () => {};

module.exports = deleteUser;
