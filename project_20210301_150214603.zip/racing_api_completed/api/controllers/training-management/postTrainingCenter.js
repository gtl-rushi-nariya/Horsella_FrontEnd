const validator = require("validator");
const CreateTrainingCenter = require("../../../utilities/db/training/postTrainingCenter");

let trainigCenter = {
  id: null,
  centerName: null,
  ownerName: null,
  description: null,
  workingHours: null,
  experience: null,
  contact: null,
  email: null,
  address: null,
  website: null,
  imagePath: null,
};

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const isNotString = (param) => typeof param !== "string";

const validateCredentials = ({
  centerName,
  ownerName,
  description,
  workingHours = null,
  experience = null,
  contact,
  email,
  address,
  website = null,
  imagePath = null,
}) => {
  if (isNotString(centerName) || centerName.length < 3) {
    throw new Error("Invalid Center Name");
  }
  if (isNotString(ownerName) || ownerName.length < 3) {
    throw new Error("Invalid Owner Name");
  }
  if (isNotString(description) || description.length < 10) {
    throw new Error("Invalid Description");
  }
  if (isNotString(email) || !validator.isEmail(email)) {
    throw new Error("Invalid Email");
  }
  if (
    experience !== null &&
    (isNotString(experience) ||
      !validator.isInt(experience, { min: 1, max: 100 }))
  ) {
    throw new Error("Invalid Experience");
  }
  if (isNotString(address) || address.length < 10) {
    throw new Error("Invalid Address");
  }
  if (website !== null && (isNotString(website) || website.length < 3)) {
    throw new Error("Invalid Website URL");
  }
  if (
    workingHours !== null &&
    (isNotString(workingHours) || workingHours.length < 3)
  ) {
    throw new Error("Invalid Working Hours");
  }

  if (isNotString(contact) || !validator.isMobilePhone(contact, "en-IN")) {
    throw new Error("Invalid Contact");
  }
  if (imagePath !== null && (isNotString(website) || imagePath.length < 3)) {
    throw new Error("Invalid Image Path");
  }
  trainigCenter = {
    centerName,
    ownerName,
    description,
    workingHours,
    experience: parseInt(experience),
    contact,
    email,
    address,
    website,
    imagePath,
  };
};

const postTrainingCenter = async (req, resp) => {
  if (req.file) {
    let imageName = req.file.filename;
    req.body.imagePath = imageName;
  } else {
    req.body.imagePath = null;
  }
  // console.log("image is herer:");
  // console.log(req.file);
  // console.log(req.body);

  try {
    if (req.body === undefined || req.body === null) {
      throw new Error("No data found");
    } else {
      validateCredentials(req.body);
      CreateTrainingCenter(trainigCenter)
        .then((values) => {
          resp.status(201).json({
            status: 201,
            data: {
              centerName: values.centerName,
              ownerName: values.ownerName,
              email: values.email,
              address: values.address,
              imagePath: values.imagePath,
            },
            error: null,
          });
        })
        .catch((err) => {
          returnError(err, resp);
        });
    }
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = postTrainingCenter;
