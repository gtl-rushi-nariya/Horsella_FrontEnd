const validator = require("validator");
const getTrainingCenters = require("../../../utilities/db/training/getAllTrainingCenters");

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const getAllTrainingCenters = async (req, resp) => {
  try {
    getTrainingCenters()
      .then((values) => {
        resp.status(200).json({
          status: 200,
          data: values,
          error: null,
        });
      })
      .catch((err) => {
        returnError(err, resp);
      });
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = getAllTrainingCenters;
