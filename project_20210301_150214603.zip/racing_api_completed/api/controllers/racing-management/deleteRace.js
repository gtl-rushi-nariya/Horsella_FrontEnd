const validator = require("validator");
const deleteRaceById = require("../../../utilities/db/racing/deleteRace");

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const deleteRace = async (req, resp) => {
  var entityData = {
    Id: req.params.id,
  };

  function validateFields(req, res) {
    return new Promise(function (resolve, reject) {
      var isUserIdEmpty = validator.isEmpty(entityData.Id);
      if (isUserIdEmpty) {
        return reject("Race id is null");
      }

      return resolve("id exists");
    });
  }

  try {
    validateFields(req, resp)
      .then(function (response) {
        return deleteRaceById(entityData.Id);
      })
      .then((values) => {
        if (values != null) {
          resp.status(200).json({
            status: 200,
            data: {
              raceName: values.raceName,
              racecourse: values.racecourse,
              RaceDate: values.RaceDate,
              raceHorseAgeCriteria: values.raceHorseAgeCriteria,
              isCancelled: values.isCancelled,
            },
            error: null,
          });
        } else {
          resp.status(200).json({
            status: 200,
            data: `Race with id : ${entityData.Id} can't delete !!!`,
            error: null,
          });
        }
      })
      .catch(function (err) {
        console.error(err.message);
        returnError(err, resp);
      });
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = deleteRace;
