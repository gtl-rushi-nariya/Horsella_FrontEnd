//postRace
const validator = require("validator");
const CreateRace = require("../../../utilities/db/racing/postRace");

let newRace = {
  id: null,
  raceName: null,
  racecourse: null,
  RaceDate: null,
  raceLength: null,
  raceHorseAgeCriteria: null,
  RaceHorseWeightCriteria: null,
};

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const isNotString = (param) => typeof param !== "string";

const validateCredentials = ({
  id,
  raceName,
  racecourse,
  RaceDate,
  raceLength,
  raceHorseAgeCriteria,
  RaceHorseWeightCriteria,
}) => {
  if (isNotString(raceName) || raceName.length < 3) {
    throw new Error("Invalid Center Name");
  }
  if (isNotString(racecourse) || racecourse.length < 3) {
    throw new Error("Invalid Owner Name");
  }
  if (
    isNotString(raceLength) ||
    !validator.isInt(raceLength, { min: 1, max: 1000 })
  ) {
    throw new Error("Invalid raceLength");
  }
  if (
    isNotString(raceHorseAgeCriteria) ||
    !validator.isInt(raceHorseAgeCriteria, { min: 3, max: 20 })
  ) {
    throw new Error("Invalid raceHorseAgeCriteria");
  }
  if (
    isNotString(RaceHorseWeightCriteria) ||
    !validator.isInt(RaceHorseWeightCriteria, { min: 3, max: 20 })
  ) {
    throw new Error("Invalid RaceHorseWeightCriteria");
  }
  newRace = {
    id,
    raceName,
    racecourse,
    RaceDate,
    raceLength,
    raceHorseAgeCriteria: parseInt(raceHorseAgeCriteria),
    RaceHorseWeightCriteria: parseInt(RaceHorseWeightCriteria),
  };
};

const postRace = async (req, resp) => {
  try {
    if (req.body === undefined || req.body === null) {
      throw new Error("No data found");
    } else {
      validateCredentials(req.body);
      CreateRace(newRace)
        .then((values) => {
          resp.status(201).json({
            status: 201,
            data: {
              raceName: values.raceName,
              racecourse: values.racecourse,
              RaceDate: values.RaceDate,
              raceHorseAgeCriteria: values.raceHorseAgeCriteria,
            },
            error: null,
          });
        })
        .catch((err) => {
          returnError(err, resp);
        });
    }
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = postRace;
