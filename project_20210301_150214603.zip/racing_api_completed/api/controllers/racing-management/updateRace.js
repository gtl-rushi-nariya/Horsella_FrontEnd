const validator = require("validator");
const putRace = require("../../../utilities/db/racing/updateRace");

let updatedRace = {
  id: null,
  raceName: null,
  racecourse: null,
  RaceDate: null,
  raceLength: null,
  raceHorseAgeCriteria: null,
  RaceHorseWeightCriteria: null,
};

const returnError = (err, resp) => {
  // TODO Switch case for respective error types
  resp.status(400).json({
    status: 400,
    error: {
      message: err.message,
    },
    data: null,
  });
};

const isNotString = (param) => typeof param !== "string";

const validateCredentials = ({
  raceName,
  racecourse,
  RaceDate,
  raceLength,
  raceHorseAgeCriteria,
  RaceHorseWeightCriteria,
}) => {
  if (isNotString(raceName) || raceName.length < 3) {
    throw new Error("Invalid Center Name");
  }
  if (isNotString(racecourse) || racecourse.length < 3) {
    throw new Error("Invalid Owner Name");
  }
  if (
    isNotString(raceLength) ||
    !validator.isInt(raceLength, { min: 1, max: 1000 })
  ) {
    throw new Error("Invalid raceLength");
  }
  if (
    isNotString(raceHorseAgeCriteria) ||
    !validator.isInt(raceHorseAgeCriteria, { min: 3, max: 20 })
  ) {
    throw new Error("Invalid raceHorseAgeCriteria");
  }
  if (
    isNotString(RaceHorseWeightCriteria) ||
    !validator.isInt(RaceHorseWeightCriteria, { min: 3, max: 20 })
  ) {
    throw new Error("Invalid RaceHorseWeightCriteria");
  }

  updatedRace = {
    raceName,
    racecourse,
    RaceDate,
    raceLength,
    raceHorseAgeCriteria: parseInt(raceHorseAgeCriteria),
    RaceHorseWeightCriteria: parseInt(RaceHorseWeightCriteria),
  };
};

const updateRace = async (req, resp) => {
  var entityData = {
    Id: req.params.id,
  };

  function validateFields(req, res) {
    return new Promise(function (resolve, reject) {
      var isUserIdEmpty = validator.isEmpty(entityData.Id);
      if (isUserIdEmpty) {
        return reject("Race id is null");
      }

      return resolve("id exists");
    });
  }

  try {
    if (req.body === undefined || req.body === null) {
      throw new Error("No data found");
    } else {
      validateCredentials(req.body);
      validateFields(req, resp)
        .then(function (response) {
          return putRace(updatedRace, entityData.Id);
        })
        .then((values) => {
          resp.status(200).json({
            status: 200,
            data: {
              raceName: values.raceName,
              racecourse: values.racecourse,
              RaceDate: values.RaceDate,
              raceHorseAgeCriteria: values.raceHorseAgeCriteria,
            },
            error: null,
          });
        })
        .catch(function (err) {
          console.error(err.message);
          returnError(err, resp);
        });
    }
  } catch (err) {
    console.error(err.message);
    returnError(err, resp);
  }
};

module.exports = updateRace;
