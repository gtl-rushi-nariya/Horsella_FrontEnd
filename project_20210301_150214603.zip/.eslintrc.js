/* eslint-disable linebreak-style */
module.exports = {
  env: {
    browser: true,
    commonjs: true,
    es2021: true,
  },
  extends: ['eslint:recommended', 'airbnb-base'],
  parserOptions: {
    ecmaVersion: 12,
  },
  rules: {
    'linebreak-style': ['warn', 'windows'],
    semi: ['warn', 'always'],
    'no-console': 0,
    'no-unused-vars': 0,
    'max-len': ['warn', { code: 120 }],
  },
};
