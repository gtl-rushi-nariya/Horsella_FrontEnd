const horses = [
  {
    id: "1",
    name: "horse1",
    price: "2000$",
    breedType: "hunter",
    mainDiscipline: "Jumping, Dressage Breeding",
    color: "black",
    age: "13",
    height: "15hh",
    location: "Germany",
    description:
      "Many prospective horse owners contact a trotting trainer to get help before the purchase. Trainers generally also have good contacts with breeders, for those who are looking for a young horse. It is increasingly common for horses to be sold in consortia and shares, ie several people own the horse together.First second … Several trotting sites on the internet have buying and selling forums. Advertisements are also available in trade magazines. A few times a year, including in connection with the Elite Race in the spring and the Swedish Trotting Criterium in the autumn, trotting horse auctions are arranged in Sweden. Young horses are usually sold, but on occasion occasional competition horses and foals are also offered. Really promising horses generally get expensive at the auctions, but there are several examples of stars being called in for low amounts. Trotting horses are also sold via internet-based auctions.",
  },
  {
    id: "2",
    name: "horse2",
    price: "3000$",
    breedType: "hunter",
    mainDiscipline: "Jumping, Dressage Breeding",
    color: "black",
    age: "13",
    height: "15hh",
    location: "Germany",
    description:
      "   Suresh Dasari is a founder and technical leaddeveloper in tutlane.Suresh Dasari is a founder andtechnical lead developer in tutlane.Suresh Dasari is a founder and technical lead developer in tutlane.",
  },
  {
    id: "3",
    name: "horse3",
    price: "4000$",
    breedType: "hunter",
    mainDiscipline: "Jumping, Dressage Breeding",
    color: "black",
    age: "13",
    height: "15hh",
    location: "Germany",
    description:
      "   Suresh Dasari is a founder and technical leaddeveloper in tutlane.Suresh Dasari is a founder andtechnical lead developer in tutlane.Suresh Dasari is a founder and technical lead developer in tutlane.",
  },
  {
    id: "4",
    name: "horse4",
    price: "5000$",
    breedType: "hunter",
    mainDiscipline: "Jumping, Dressage Breeding",
    color: "black",
    age: "13",
    height: "15hh",
    location: "Germany",
    description:
      "   Suresh Dasari is a founder and technical leaddeveloper in tutlane.Suresh Dasari is a founder andtechnical lead developer in tutlane.Suresh Dasari is a founder and technical lead developer in tutlane.",
  },
];

export default horses;
